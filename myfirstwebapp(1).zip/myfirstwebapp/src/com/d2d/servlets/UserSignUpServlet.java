package com.d2d.servlets;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.neo4j.graphdb.DynamicLabel;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Transaction;

import com.d2d.servlets.listeners.D2DServletContextListener;

public class UserSignUpServlet extends HttpServlet
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private BufferedWriter logWriter = null;

    public UserSignUpServlet()
    {
        System.out.println( ">>>>>>>>>>>>>>>>> INSIDE CONSTRUCTOR <<<<<<<<<<<<<<<<<<<" );
    }

    @Override
    public void destroy()
    {
        if ( logWriter != null )
        {
            System.out.println( "Closing the log file....." );
            try
            {
                logWriter.close();
            }
            catch ( IOException e )
            {
                System.err.println( "Unable to close the log file - " + e.getMessage() );
            }
        }
        super.destroy();
    }

    @Override
    public void init() throws ServletException
    {
        String logFileLocation = getServletConfig().getInitParameter( "logFileLocation" );
        if ( logFileLocation != null && logFileLocation.trim().length() > 0 )
        {
            File logFolder = new File( logFileLocation );
            if ( !logFolder.exists() )
            {
                logFolder.mkdir();
            }
            String logFileName = logFolder.getAbsolutePath() + File.separator + "user-"
                    + new Date().toString().replaceAll( " ", "_" ) + ".log";
            try
            {
                logWriter = new BufferedWriter( new FileWriter( logFileName ) );
            }
            catch ( IOException e )
            {
                System.err.println( "Unable to create the log file - " + e.getMessage() );
                logWriter = null;
            }
        }
    }

    public void logRequest( HttpServletRequest request )
    {
        if ( logWriter != null && request != null )
        {
            try
            {
                long currentTime = System.currentTimeMillis();
                Date currentDate = new Date( currentTime );
                logWriter.write( "Request received at : " + currentDate + "(" + currentTime + ")\n" );
                logWriter.write( "Request URI : " + request.getRequestURI() );
                logWriter.write( request.getContextPath() + "/" + request.getContentType() + "/"
                        + request.getCharacterEncoding() );

                StringBuffer sb = new StringBuffer();
                sb.append( request.getScheme() );
                sb.append( "://" );
                sb.append( request.getServerName() );
                sb.append( ":" );
                sb.append( request.getServerPort() );
                sb.append( "/" );
                sb.append( request.getContextPath() );
                sb.append( "/" );
                sb.append( request.getServletPath() );
                sb.append( "/" );
                sb.append( request.getPathInfo() );
                logWriter.write( "\n" + sb.toString() + "\n" );

                Enumeration<String> reqParams = request.getParameterNames();
                if ( reqParams != null && reqParams.hasMoreElements() )
                {
                    logWriter.write( "\nRequest Parameters\n" );
                    while ( reqParams.hasMoreElements() )
                    {
                        String paramName = reqParams.nextElement();
                        String paramValue = request.getParameter( paramName );
                        logWriter.write( paramName + " = " + paramValue + "\n" );
                    }
                }
                Enumeration<String> reqHeaders = request.getHeaderNames();
                if ( reqHeaders != null && reqHeaders.hasMoreElements() )
                {
                    logWriter.write( "\nRequest Headers\n" );
                    while ( reqHeaders.hasMoreElements() )
                    {
                        String headerName = reqHeaders.nextElement();
                        String headerValue = request.getHeader( headerName );
                        logWriter.write( headerName + " = " + headerValue + "\n" );
                    }
                }
                logWriter.flush();
            }
            catch ( IOException e )
            {
                System.err.println( "Unable to write to the log file - " + e.getMessage() );
            }
        }
    }

    @Override
    protected void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException,
            IOException
    {
        logRequest( request );
        response.setContentType( "text/html" );

        StringBuffer sb = new StringBuffer();
        sb.append( "<html>" );
        sb.append( "<head>" );
        sb.append( "<title>User Sign Up</title>" );
        sb.append( "<link rel='stylesheet' href='http://netdna.bootstrapcdn.com/bootswatch/3.1.1/flatly/bootstrap.min.css'/>" );
        sb.append( "</head>" );
        sb.append( "<body>" );
        sb.append( "<div class='container'>" );
        sb.append( "<div class='row'>" );
        sb.append( "<hr/>" );
        sb.append( "</div>" );
        sb.append( "<div class='row'>" );
        sb.append( "<div class='col-sm-3'></div>" );
        sb.append( "<div class='col-sm-6'>" );
        sb.append( "<div class='panel panel-default'>" );
        sb.append( "<div class='panel-heading'>" );
        sb.append( "<p>User Sign Up</p>" );
        sb.append( "</div>" );
        sb.append( "<div class='panel-body'>" );
        sb.append( "<div class='row'>" );
        sb.append( "<div class='col-sm-12'>" );
        sb.append( "<form class='form-horizontal' action='/sdo/user/signup' method='POST'>" );
        sb.append( "<div class='form-group'>" );
        sb.append( "<label for='userName' class='control-label col-sm-3'>User Name</label>" );
        sb.append( "<div class='col-sm-9'>" );
        sb.append( "<input class='form-control' id='userName' name='userName' type='text' placeholder='User Name'/>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "<div class='form-group'>" );
        sb.append( "<label for='password' class='control-label col-sm-3'>Password</label>" );
        sb.append( "<div class='col-sm-9'>" );
        sb.append( "<input class='form-control' id='password' name='password' type='password' placeholder='Password'/>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "<div class='form-group'>" );
        sb.append( "<label for='name' class='control-label col-sm-3'>Name</label>" );
        sb.append( "<div class='col-sm-9'>" );
        sb.append( "<input class='form-control' id='name' name='name' type='text' placeholder='Name'/>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "<div class='form-group'>" );
        sb.append( "<hr/>" );
        sb.append( "<div class='col-sm-3'></div><div>" );
        sb.append( "<input class='btn btn-primary' type='submit' value='Sign Up'/>&nbsp;" );
        sb.append( "<input class='btn btn-default' type='reset' value='Clear'/>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "</form>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "</div>" );
        sb.append( "<script type='text/javascript' src='https://code.jquery.com/jquery-1.11.0.min.js'></script>" );
        sb.append( "<script type='text/javascript' src='http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js'/>" );
        sb.append( "</body>" );
        sb.append( "</html>" );
        response.getWriter().write( sb.toString() );
    }

    @Override
    protected void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException,
            IOException
    {
        logRequest( request );
        response.setContentType( "text/html" );

        String userName = request.getParameter( "userName" );
        String password = request.getParameter( "password" );
        String name = request.getParameter( "name" );

        System.out.println( "User Name : " + userName );
        System.out.println( "Password : " + password );
        System.out.println( "Name : " + name );

        // Create the node with the userName, password &
        // name as the properties on the node
        // What is the label? Users
        // Api to use is createNode(..)
        // Where is the api present? on GraphDatabaseService
        // How do i access GraphDatabaseService?
        // Get the servlet context and on that, access the attribtue
        // "GraphDatabase" which returns a reference to the
        // GraphDatabaseService

        PrintWriter out = response.getWriter();
        out.write( "<html><head><title>User Creation</title></head><body>" );
        ServletContext sc = getServletContext();
        Object value = sc.getAttribute( D2DServletContextListener.KEY_GRAPH_DATABASE );
        if ( value instanceof GraphDatabaseService )
        {
            GraphDatabaseService graphDB = (GraphDatabaseService) value;
            try
            {
                createUser( graphDB, userName, password, name );
                out.write( "<p><h1>User created successfully....</h1></p>" );
            }
            catch ( Exception e )
            {
                out.write( "<p><h1>User creation failed - </h1>" + e.getMessage() + ".</p>" );
            }
        }
    }

    private Node createUser( GraphDatabaseService gds, String userName, String password, String name ) throws Exception
    {
        Node user = null;

        if ( gds != null && userName != null && userName.length() > 0 && password != null && password.length() > 0 )
        {
            try ( Transaction tx = gds.beginTx() )
            {
                Label l = DynamicLabel.label( "Users" );
                user = gds.createNode( l );
                user.setProperty( "userName", userName );
                user.setProperty( "password", password );
                user.setProperty( "name", name );
                tx.success();
            }
        }
        else
        {
            throw new Exception( "One of the required inputs is empty" );
        }

        return user;
    }

}
