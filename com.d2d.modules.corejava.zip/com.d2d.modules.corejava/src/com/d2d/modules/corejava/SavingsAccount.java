package com.d2d.modules.corejava;

public class SavingsAccount extends BankAccount
{
//    @Override
//    public double getRateOfInterest()
//    {
//        return 13.0;
//    }

}
