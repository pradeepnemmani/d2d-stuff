package com.d2d.modules.corejava.generics;

public interface IProduce
{
    String getName();
    
    void setName(String name);
    
}
