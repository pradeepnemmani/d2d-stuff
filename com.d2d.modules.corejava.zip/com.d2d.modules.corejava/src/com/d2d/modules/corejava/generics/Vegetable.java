package com.d2d.modules.corejava.generics;

public class Vegetable extends Produce implements IVegetable
{
}
