package com.d2d.modules.corejava.generics;

public interface IVegetable extends IProduce
{
}
