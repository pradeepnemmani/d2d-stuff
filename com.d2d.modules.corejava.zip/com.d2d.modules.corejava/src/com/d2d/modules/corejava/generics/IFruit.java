package com.d2d.modules.corejava.generics;

public interface IFruit extends IProduce
{
    String getColor();

    void setColor( String color );
}
