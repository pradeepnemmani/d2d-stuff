package com.d2d.modules.corejava.threads.producerconsumer;

public interface IPhone
{
    String getModelNumber();

    void setModelNumber( String modelNumber );

    String getSerialNumber();

    void setSerialNumber( String serialNumber );

    int getManufacturingYear();

    void setManufacturingYear( int manufacturingYear );
}
