package com.d2d.modules.corejava;

public class BankAccount
{

    public double getRateOfInterest()
    {
        return 12.5;
    }
}
