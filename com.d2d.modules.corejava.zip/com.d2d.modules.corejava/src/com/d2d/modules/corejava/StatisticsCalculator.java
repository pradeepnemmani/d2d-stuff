package com.d2d.modules.corejava;

public class StatisticsCalculator extends Calculator
{

    public void median( int[] numbers )
    {
        System.out.println( "Inside median()" );
    }

    public void mode( int[] numbers )
    {
        System.out.println( "Inside mode()" );
    }
}
