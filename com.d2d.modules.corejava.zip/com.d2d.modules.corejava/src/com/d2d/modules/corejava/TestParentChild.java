package com.d2d.modules.corejava;

public class TestParentChild
{

    public static void main( String[] args )
    {
        Child c = new Child();
    }

}
