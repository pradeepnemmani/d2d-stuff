package com.d2d.modules.corejava.exceptions;

public class ScientificCalculator extends Calculator
{

    public ScientificCalculator()
    {
    }

    @Override
    public int divide( int numerator, int denominator )
            throws InvalidInputException, Exception
    {
        return super.divide( numerator, denominator );
    }

}
