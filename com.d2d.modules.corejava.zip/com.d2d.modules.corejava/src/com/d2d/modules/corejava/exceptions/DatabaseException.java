package com.d2d.modules.corejava.exceptions;

public class DatabaseException extends Exception
{

    public DatabaseException( String message )
    {
        super( message );
    }

}
