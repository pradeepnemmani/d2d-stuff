package com.d2d.modules.corejava;

public class Child extends Parent
{
    public Child()
    {
    }

    public void displayMessage()
    {
        System.out.println( "Child..." );
    }
}
