package com.d2d.modules.corejava.io.streams.object;

public enum EnumTaste
{
    SWEET, SOUR, BITTER, SALTY
}
