package com.d2d.modules.corejava.io.streams.object;

public enum EnumColor
{
    RED, GREEN, YELLOW, ORANGE, PURPLE
}
